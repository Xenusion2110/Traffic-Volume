from flask import Flask, jsonify, render_template
from api.congestion import congestion_api, get_congestion_data
from api.trend import get_trend_data
from api.weather_impact import get_weather_impact
import matplotlib
matplotlib.use('Agg')  # Set the backend to Agg (no GUI needed)
import matplotlib.pyplot as plt
import io
import base64
import sys
import os

# Add the project root directory to sys.path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from scripts.ml_models import get_kmeans_plot, get_decision_tree_plot


# Initialize Flask app
app = Flask(__name__, template_folder='../templates', static_folder='../static')

# Register Blueprints
app.register_blueprint(congestion_api)


# Root homepage route
@app.route("/")
def index():
    return render_template("index.html")

# API Routes
@app.route("/congestion")
def congestion():
    return jsonify(get_congestion_data())  # Returns congestion data in JSON format

@app.route("/trend")
def trend():
    return jsonify(get_trend_data())  # Returns trend data in JSON format

@app.route("/borough")
def borough():
    return jsonify(get_top_street_data())  # Returns borough data in JSON format

@app.route("/weather-impact")
def weather_impact():
    return jsonify(get_weather_impact())  # Returns weather impact data in JSON format

# View Routes (for rendering HTML templates)
@app.route("/view/congestion")
def view_congestion():
    congestion_data = get_congestion_data()  # Fetch the data
    if congestion_data:
        # Generate the plot
        street_names = [item['street'] for item in congestion_data]
        traffic_volumes = [item['traffic_volume'] for item in congestion_data]

        fig, ax = plt.subplots(figsize=(10, 5))
        ax.bar(street_names, traffic_volumes, color='skyblue')
        ax.set_xlabel('Street')
        ax.set_ylabel('Traffic Volume')
        ax.set_title('Traffic Congestion by Street')
        plt.xticks(rotation=45, ha='right')
        plt.tight_layout()

        # Convert plot to image
        img = io.BytesIO()
        plt.savefig(img, format='png')
        img.seek(0)
        plot_url = base64.b64encode(img.getvalue()).decode()
        plt.close()

        return render_template('congestion.html', image_data=plot_url, congestion_data=congestion_data)
    else:
        return render_template('congestion.html', message="No data available.")


@app.route("/view/trend")
def view_trend():
    return render_template("trend.html")

@app.route("/view/borough")
def view_borough():
    return render_template("borough.html")

@app.route("/view/weather-impact")
def view_weather_impact():
    return render_template("weather_impact.html")

@app.route('/api/kmeans-cluster')
def kmeans_cluster():
    img = get_kmeans_plot()
    return jsonify({'image': img})

@app.route('/api/decision-tree')
def decision_tree():
    img = get_decision_tree_plot()
    return jsonify({'image': img})

@app.route('/view/kmeans')
def view_kmeans():
    plot_url = get_kmeans_plot()
    return render_template('kmeans.html', plot_url=plot_url)


@app.route('/view/decision-tree')
def view_decision_tree():
    plot_url = get_decision_tree_plot()
    return render_template('decision_tree.html', plot_url=plot_url)

# Run the Flask app
if __name__ == "__main__":
    app.run(debug=True)

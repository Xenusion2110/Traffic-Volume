def get_trend_data():
    import pandas as pd
    import os

    data_path = os.path.join("data", "final_cleaned_traffic_weather.csv")
    df = pd.read_csv(data_path)

    if 'date' in df.columns and 'Vol' in df.columns:
        df['date'] = pd.to_datetime(df['date'])
        df = df[df['Vol'] > 0]
        trend_df = df.groupby('date')['Vol'].mean().reset_index()
        trend_df.rename(columns={'Vol': 'average_volume'}, inplace=True)
        return trend_df.to_dict(orient='records')
    else:
        return {"error": "Missing required columns"}

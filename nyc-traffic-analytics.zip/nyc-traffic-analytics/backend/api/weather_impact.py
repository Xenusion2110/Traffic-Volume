def get_weather_impact():
    result = []
    with open("/Users/mohdshoyeb/Desktop/Big data Analytics/Project/nyc-traffic-analytics/output/weather_impact_results.txt", "r") as file:
        for line in file:
            if "\t" in line:
                weather, volume = line.strip().split("\t")
                result.append({"weather": weather, "volume": int(volume)})
    return result

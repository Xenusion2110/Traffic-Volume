# api/congestion.py

from flask import Blueprint, jsonify
import os

# Define the Blueprint for congestion
congestion_api = Blueprint('congestion_api', __name__)

# Path to the congestion results file
CONGESTION_FILE_PATH = '/Users/mohdshoyeb/Desktop/Big data Analytics/Project/nyc-traffic-analytics/output/congestion_results.txt'

def get_congestion_data():
    if not os.path.exists(CONGESTION_FILE_PATH):
        return []

    congestion_data = []

    with open(CONGESTION_FILE_PATH, 'r') as file:
        lines = file.readlines()
        for line in lines:
            try:
                # Split by tabs and capture street name and traffic volume
                parts = line.strip().split('\t')
                if len(parts) == 2:
                    street, volume = parts
                    congestion_data.append({'street': street, 'traffic_volume': int(volume)})
            except ValueError:
                continue  # Skip lines that can't be processed

    return congestion_data

# Define the route for the congestion API
@congestion_api.route('/congestion')
def congestion():
    congestion_data = get_congestion_data()
    return jsonify(congestion_data)

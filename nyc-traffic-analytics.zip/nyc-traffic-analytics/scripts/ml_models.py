import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.tree import DecisionTreeClassifier, plot_tree
import base64
from io import BytesIO

# Dataset Path
DATA_PATH = "data/final_cleaned_traffic_weather.csv"

# Load dataset
def load_data():
    df = pd.read_csv(DATA_PATH)
    return df

# Function to add 'congestion_level' based on traffic volume
def add_congestion_level(df):
    bins = [0, 0.3, 0.6, 1.0]  # Customize these thresholds as needed
    labels = ['Low', 'Medium', 'High']
    df['congestion_level'] = pd.cut(df['traffic_volume_scaled'], bins=bins, labels=labels)
    return df

# KMeans Clustering function
def get_kmeans_plot():
    df = load_data()

    # Selecting the relevant features for clustering
    X = df[['is_rain', 'is_snow', 'traffic_volume_scaled']].dropna()

    # Standardizing the data
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    # Apply KMeans clustering
    kmeans = KMeans(n_clusters=3, random_state=42)
    y_kmeans = kmeans.fit_predict(X_scaled)

    # Plotting the clusters
    plt.figure(figsize=(8, 6))
    plt.scatter(X_scaled[:, 0], X_scaled[:, 1], c=y_kmeans, cmap='viridis')
    plt.title("KMeans Clustering: Weather → Traffic Volume")
    plt.xlabel("Rain (0: No, 1: Yes)")
    plt.ylabel("Snow (0: No, 1: Yes)")
    plt.colorbar(label='Cluster')

    # Convert plot to base64 for embedding in Flask response
    img = BytesIO()
    plt.savefig(img, format='png')
    img.seek(0)
    plot_url = base64.b64encode(img.getvalue()).decode()
    plt.close()
    return plot_url

def get_decision_tree_plot():
    df = load_data()
    df = add_congestion_level(df)

    df = df[['is_rain', 'is_snow', 'traffic_volume_scaled', 'congestion_level']].dropna()

    X = df[['is_rain', 'is_snow', 'traffic_volume_scaled']]
    y = df['congestion_level']
    print("Congestion class counts:\n", y.value_counts())

    # Fit model
    model = DecisionTreeClassifier(max_depth=4, random_state=42)

    model.fit(X, y)

    # ✅ Get sorted unique class names as strings
    class_names = sorted(model.classes_.astype(str))

    # Plot
    plt.figure(figsize=(12, 6))
    plot_tree(model, feature_names=X.columns, class_names=class_names,
              filled=True, impurity=True, proportion=True, rounded=True)

    # Encode image
    img = BytesIO()
    plt.savefig(img, format='png')
    img.seek(0)
    plot_url = base64.b64encode(img.getvalue()).decode()
    plt.close()

    return plot_url


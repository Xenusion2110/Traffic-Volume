#!/bin/bash

cd "$(dirname "$0")"/..

mkdir -p output

echo "Running Congestion Hotspots MapReduce..."
cat "/Users/mohdshoyeb/Desktop/Big data Analytics/Project/nyc-traffic-analytics/data/final_cleaned_traffic_weather.csv" | python3 mappers/congestion_mapper.py | sort | python3 reducers/congestion_reducer.py > output/congestion_results.txt
echo "Congestion hotspots written to output/congestion_results.txt"

echo "Running Traffic Volume Trend MapReduce..."
cat "/Users/mohdshoyeb/Desktop/Big data Analytics/Project/nyc-traffic-analytics/data/final_cleaned_traffic_weather.csv" | python3 mappers/trend_mapper.py | sort | python3 reducers/trend_reducer.py > output/trend_results.txt
echo "Traffic trend written to output/trend_results.txt"

echo "Running Weather Impact MapReduce..."
cat "/Users/mohdshoyeb/Desktop/Big data Analytics/Project/nyc-traffic-analytics/data/final_cleaned_traffic_weather.csv" | python3 mappers/weather_impact_mapper.py | sort | python3 reducers/weather_impact_reducer.py > output/weather_impact_results.txt
echo "Weather impact results written to output/weather_impact_results.txt"


echo "All MapReduce jobs completed successfully."

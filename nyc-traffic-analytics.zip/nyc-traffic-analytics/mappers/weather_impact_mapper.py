#!/usr/bin/env python3
import sys
import csv

reader = csv.DictReader(sys.stdin)
for row in reader:
    conditions = row.get("conditions", "")
    volume = row.get("traffic_volume", "")

    if conditions and volume:
        try:
            volume = int(volume)
            condition_lower = conditions.lower()

            if 'rain' in condition_lower:
                print(f"Rain\t{volume}")
            elif 'snow' in condition_lower:
                print(f"Snow\t{volume}")
            elif 'clear' in condition_lower:
                print(f"Clear\t{volume}")
            elif 'overcast' in condition_lower:
                print(f"Overcast\t{volume}")
            elif 'cloud' in condition_lower:
                print(f"Partially Cloudy\t{volume}")
        except ValueError:
            continue

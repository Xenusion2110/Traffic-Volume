import sys
import csv

for line in sys.stdin:
    row = line.strip().split(',')
    if len(row) >= 5:
        street = row[2].strip()  # Example index for street name
        volume = row[4].strip()  # Example index for traffic volume
        if street and volume.isdigit():
            print(f"{street}\t{volume}")
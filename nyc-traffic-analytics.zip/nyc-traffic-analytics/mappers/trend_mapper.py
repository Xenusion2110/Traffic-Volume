#!/usr/bin/env python3
import sys, csv

reader = csv.DictReader(sys.stdin)
for row in reader:
    date = row.get("date")
    volume = row.get("traffic_volume")
    if date and volume:
        try:
            print(f"{date.strip()}\t{int(volume)}")
        except ValueError:
            continue

#!/usr/bin/env python3
import sys

current_condition = None
total = 0
count = 0

for line in sys.stdin:
    condition, volume = line.strip().split('\t')
    volume = int(volume)

    if condition == current_condition:
        total += volume
        count += 1
    else:
        if current_condition:
            avg = total // count
            print(f"{current_condition}\t{avg}")
        current_condition = condition
        total = volume
        count = 1

if current_condition:
    avg = total // count
    print(f"{current_condition}\t{avg}")

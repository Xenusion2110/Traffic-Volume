#!/usr/bin/env python3
import sys

current_date = None
total = 0
count = 0

for line in sys.stdin:
    date, volume = line.strip().split('\t')
    volume = int(volume)

    if date == current_date:
        total += volume
        count += 1
    else:
        if current_date:
            avg = total // count
            print(f"{current_date}\t{avg}")
        current_date = date
        total = volume
        count = 1

if current_date:
    avg = total // count
    print(f"{current_date}\t{avg}")

import sys
from collections import defaultdict

traffic_data = defaultdict(int)

for line in sys.stdin:
    parts = line.strip().split('\t')
    if len(parts) == 2:
        street, volume = parts
        try:
            traffic_data[street] += int(volume)
        except ValueError:
            continue

for street, total_volume in traffic_data.items():
    print(f"{street}\t{total_volume}")

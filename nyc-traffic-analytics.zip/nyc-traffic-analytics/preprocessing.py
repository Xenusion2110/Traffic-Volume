import pandas as pd
from datetime import datetime
from sklearn.preprocessing import MinMaxScaler # type: ignore
import numpy as np

# Loading Traffic Data
traffic_df = pd.read_csv(
    "/Users/mohdshoyeb/Desktop/Big data Analytics/Project/nyc-traffic-analytics/data/Automated_Traffic_Volume_Counts_20250429.csv",
    usecols=['Yr', 'M', 'D', 'HH', 'Vol']
)

traffic_df['date'] = pd.to_datetime(dict(year=traffic_df['Yr'], month=traffic_df['M'], day=traffic_df['D']))
traffic_df['hour'] = traffic_df['HH']

# Loading Weather Data
weather_df = pd.read_csv(
    "/Users/mohdshoyeb/Desktop/Big data Analytics/Project/nyc-traffic-analytics/data/New_York__NY__United_States.csv",
    usecols=['datetime', 'conditions']
)

weather_df['datetime'] = pd.to_datetime(weather_df['datetime'])
weather_df['date'] = weather_df['datetime'].dt.date
weather_df['hour'] = weather_df['datetime'].dt.hour

traffic_df['date'] = pd.to_datetime(traffic_df['date']).dt.date

# Merge
merged_df = pd.merge(traffic_df, weather_df, on=['date', 'hour'], how='left')
merged_df.dropna(subset=['conditions'], inplace=True)
merged_df.drop_duplicates(inplace=True)

# Feature engineering
merged_df['is_rain'] = merged_df['conditions'].str.contains('Rain', case=False, na=False)
merged_df['is_snow'] = merged_df['conditions'].str.contains('Snow', case=False, na=False)
merged_df['day_of_week'] = pd.to_datetime(merged_df['date']).dt.dayofweek
merged_df['is_weekend'] = merged_df['day_of_week'] >= 5

# Outlier Removal
Q1 = merged_df['Vol'].quantile(0.25)
Q3 = merged_df['Vol'].quantile(0.75)
IQR = Q3 - Q1
lower_bound = Q1 - 1.5 * IQR
upper_bound = Q3 + 1.5 * IQR
merged_df = merged_df[(merged_df['Vol'] >= lower_bound) & (merged_df['Vol'] <= upper_bound)]

# Encode weather
merged_df['weather_main'] = merged_df['conditions'].str.extract(r'(\w+)', expand=False)
merged_df['weather_main'] = merged_df['weather_main'].astype('category')
merged_df['weather_main_code'] = merged_df['weather_main'].cat.codes

# Normalize volume
scaler = MinMaxScaler()
merged_df['Vol_scaled'] = scaler.fit_transform(merged_df[['Vol']])

# Rename
merged_df.rename(columns={
    'Vol': 'traffic_volume',
    'Vol_scaled': 'traffic_volume_scaled'
}, inplace=True)

# 🆕 Add dummy borough, street, and location for MapReduce
np.random.seed(42)
boroughs = ['Manhattan', 'Brooklyn', 'Queens', 'Bronx', 'Staten Island']
streets = ['5th Avenue', 'Broadway', 'Queens Blvd', 'Grand Concourse', 'Victory Blvd']

merged_df['borough'] = np.random.choice(boroughs, size=len(merged_df))
merged_df['street'] = np.random.choice(streets, size=len(merged_df))
merged_df['location'] = merged_df['street'] + ', ' + merged_df['borough']

# Save
merged_df.to_csv(
    "/Users/mohdshoyeb/Desktop/Big data Analytics/Project/nyc-traffic-analytics/data/final_cleaned_traffic_weather.csv",
    index=False
)

print(merged_df['traffic_volume'].describe())
print("Final cleaned dataset saved as 'final_cleaned_traffic_weather.csv'")

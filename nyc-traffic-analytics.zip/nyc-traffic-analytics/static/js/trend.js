fetch('/trend')
  .then(response => response.json())
  .then(data => {
    const labels = data.map(item => item.date);
    const volumes = data.map(item => item.average_volume);

    const ctx = document.getElementById('trendChart').getContext('2d');
    new Chart(ctx, {
      type: 'line',
      data: {
        labels: labels,
        datasets: [{
          label: 'Average Volume',
          data: volumes,
          borderColor: 'blue',
          fill: false
        }]
      }
    });
  });

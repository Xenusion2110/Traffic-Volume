import pandas as pd
import matplotlib.pyplot as plt

# Plot Congestion Hotspots
df_congestion = pd.read_csv('output/congestion_results.txt', sep='\t', names=['street', 'volume'])
df_congestion.nlargest(10, 'volume').plot(kind='barh', x='street', y='volume', title='Top 10 Congested Streets')
plt.tight_layout()
plt.show()

# Plot Traffic Trend Over Time
df_trend = pd.read_csv('output/trend_results.txt', sep='\t', names=['date', 'avg_volume'])
df_trend['date'] = pd.to_datetime(df_trend['date'])
df_trend.sort_values('date', inplace=True)
df_trend.plot(x='date', y='avg_volume', title='Traffic Volume Trend Over Time')
plt.tight_layout()
plt.show()
